<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<style>
    input {
        border: 1px solid black !important;
    }
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />


<main style="margin-top: 4%;">

    <?php echo $__env->make('Layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <div class="d-flex flex-column align-items-stretch flex-shrink-0 " style="width: 80%;">


    <div class="container mt-3">

        <h2 class="text-center mt-2" style="color: orange;font-family: fantasy;">
            <i class="fas fa-credit-card" style="color: #646968;margin-right: 23px;"></i>
           ADD CUSTOMER
        </h2>

        <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


        <hr>
      <div class="row">

      <form method="POST" action="/addcustomers">
            <?php echo csrf_field(); ?>
            <div class="row mb-3">
                <div class="col-sm-6" style="">


                    <div class="row">
                        <p>PERSONAL INFORMATION</p>
                        <div class="col-sm-4">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control form-control-sm" value="<?php echo e(old('name')); ?>" id="name" name="name" >        
                        </div>
                        <div class="col-sm-4">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control form-control-sm" value="<?php echo e(old('email')); ?>" id="email" name="email" >       
                        </div>
                        <div class="col-sm-4">
                            <label for="contactno" class="form-label">Contact   </label>
                            <input type="tel" class="form-control form-control-sm" value="<?php echo e(old('contactno')); ?>" id="contactno" name="contactno" >        
                        </div>
                    </div>



                </div>
                <div class="col-sm-6">
                    <div class="row">
                        <p>RESIDENTIAL INFORMATION</p>
                        <div class="col-sm-4">
                                <label for="address" class="form-label">Address 1 </label>
                                <input class="form-control form-control-sm" id="address" value="<?php echo e(old('address')); ?>" name="address" >
                        </div>
                        <div class="col-sm-4">
                            <label for="city" class="form-label">City</label>
                            <input type="text" class="form-control form-control-sm" value="<?php echo e(old('city')); ?>" id="city" name="city" >        
                        </div>
                        <div class="col-sm-4">
                            <label for="state" class="form-label">State</label>
                            <input type="text" class="form-control form-control-sm" value="<?php echo e(old('state')); ?>" id="state" name="state" >        
                        </div>
                        <div class="col-sm-4">
                            <label for="pincode" class="form-label">Pincode</label>
                            <input type="text" class="form-control form-control-sm" value="<?php echo e(old('pincode')); ?>" id="pincode" name="pincode" >        

                        </div>
                    </div>

                </div>

                <div class="col-sm-6">
                    <p>Accounts</p>
                    <div class="row">
                        <div class="col-sm-3">
                            <label for="gstin" class="form-label">GSTIN</label>
                            <input type="text" class="form-control form-control-sm" value="<?php echo e(old('gstin')); ?>" id="gstin" name="gstin" >
                        </div>
                        <div class="col-sm-3">
                            <label for="gstin" class="form-label">GSTIN</label>
                            <input type="text" class="form-control form-control-sm" value="<?php echo e(old('gstin')); ?>" id="gstin" name="gstin" >
                        </div>
                        <div class="col-sm-3">
                            <label for="gstin" class="form-label">GSTIN</label>
                            <input type="text" class="form-control form-control-sm" value="<?php echo e(old('gstin')); ?>" id="gstin" name="gstin" >
                        </div>
                    </div>

                </div>
    
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>


      </div>
    </div>


    </div>
  
  </main>


  <!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.7.1.js"></script>

<!-- Bootstrap Bundle (includes Popper) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

<!-- DataTables -->
<script src="https://cdn.datatables.net/2.0.1/js/dataTables.js"></script>
<script src="https://cdn.datatables.net/2.0.1/js/dataTables.bootstrap5.js"></script>
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">

<!-- DataTables Bootstrap 5 CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/2.0.1/css/dataTables.bootstrap5.css">

<script>
    	
      new DataTable('#example');
 </script>
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel_invoice\resources\views/Customers/create.blade.php ENDPATH**/ ?>