<?php $__env->startSection('title'); ?>
    LOGIN
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<style>
    input {
        border: 1px solid black;
    }
</style>



<div class="container" style="margin-top: 5%">
    <br>

    <?php if($errors->any()): ?>
    <div class="alert alert-danger m-auto w-50">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <div class="row">
      <div class="col-sm-8">

      </div>
      <div class="col-sm-4">
        <h3 style="text-align: center">LOGIN TO YOUR ACCOUNT</h3>

        <form method="POST" class="mt-1" style="border: 1px solid black;padding: 13px;border-radius: 8px;">
          <?php echo csrf_field(); ?>  
          <div class="form-group row">
                <label for="staticEmail" class="col-sm-2 col-form-label" style="color: black">Email</label>
                <div class="col-sm-10">
                  <input type="text" name="email" value="<?php echo e(old('email')); ?>" class="form-control form-control-sm" id="staticEmail" >
                </div>
              </div>
            <div class="form-group row mt-4">
              <label for="inputPassword" class="col-sm-2 col-form-label" style="color: black">Password</label>
              <div class="col-sm-10">
                <input type="password" name="password"  class="form-control form-control-sm" id="inputPassword" >
              </div>
            </div>
    
    
              <div class="form-group row mt-4">
                <label class="col-sm-2 col-form-label" style="color: black; "></label>
                <div class="col-sm-10">
                  <button type="submit" class="btn btn-info">LOGIN</button>
                </div>
              </div>
    
    
        </form>

      </div>
    </div>
   
 
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel_invoice\resources\views/Auth/Login.blade.php ENDPATH**/ ?>