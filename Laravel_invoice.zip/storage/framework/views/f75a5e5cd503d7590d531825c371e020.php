<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="refresh" content="420">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('Layouts/bootstrap', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link href="https://fonts.googleapis.com/css?family=Playfair&#43;Display:700,900&amp;display=swap" rel="stylesheet">
</head>
<body style="background: white"> 

    <?php echo $__env->make('Layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div >
        <?php echo $__env->yieldContent('content'); ?>
    </div> 
    
    <div class="footer">
        <?php echo $__env->yieldContent('footer'); ?>
    </div>


    <?php echo $__env->make('Layouts/javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    

</body>


</html><?php /**PATH C:\xampp\htdocs\Laravel_invoice\resources\views/Layouts/master.blade.php ENDPATH**/ ?>