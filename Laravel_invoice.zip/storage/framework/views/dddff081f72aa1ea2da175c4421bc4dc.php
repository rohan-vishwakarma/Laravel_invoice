<?php $__env->startSection('title'); ?>
    TAX INVOICE
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="/css/invoice.css">
    <main style="margin-top: 4%;">

        <?php echo $__env->make('Layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <style>

        </style>
        <div class="d-flex flex-column outer align-items-stretch flex-shrink-0 break-page " style="width: 80%;">



            <div class="container-fluid outer break-page">
                <div class="row">
                    <table class="">
                        <thead>
                            <tr>
                                <td colspan="8" style="border-bottom: hidden">
                                    <h4 class="text-center">TAX INVOICE</h4>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="6">
                                
                                        <img src="data:image/png;base64,<?php echo e(base64_encode($company->logo)); ?>" alt="Company Logo" style="width: 30%">
                                </td>
                                <td colspan="2">
                                    <img class="gif" src="/images/print.gif" alt="gif" onclick="printinvoice()" style="width: 30%">

                                </td>
                                
                            </tr>

                            
                            <tr style="border-top: hidden; border-bottom: hidden">
                                <td colspan="8"><b>ADDRESS</b> : <?php echo e($invoice->cadd); ?> <b>PINCODE: <?php echo e($invoice->postal_code); ?></b> </td>
                            </tr>
                            <tr style="border-top: hidden; border-bottom: hidden">
                                <td colspan="4"><b>PHONE NO</b>: <?php echo e($company->phone); ?></td>
                                <td colspan="4"><b>EMAIL</b>: <?php echo e($invoice->cemail); ?></td>
                            </tr>
                            <tr style="border-bottom: 1px solid ">
                                <td colspan="4"><b>PAN NO:</b></td>
                                <td colspan="4"><b>GSTIN</b>: <?php echo e($invoice->cgstin); ?> </td>
                            </tr>

                            <tr style=" border-bottom: hidden">
                                <td colspan="4"><b>CUSTOMER NAME</b>: <span
                                        style="font-size: 15px;"><?php echo e($invoice->customername); ?> </span></td>
                                <td colspan="4" style="border-left: 1px solid "><b>INVOICE NO :
                                        <?php echo e($invoice->invoiceno); ?>  <?php echo e($company->invoice_suffix); ?></b></td>
                            </tr>

                            <tr style=" border-bottom: hidden">
                                <td colspan="4"><b>ADDRESS : </b><?php echo e($invoice->custadd); ?>  </td>
                                <td colspan="4" style="border-left: 1px solid "><b>DATE: <?php echo e($invoice->invoicedate); ?></b>
                                </td>
                            </tr>

                            <tr style="border-bottom: 1px solid">
                                <td colspan="3"><b>GSTIN :</b> <?php echo e($invoice->custgstin); ?>  </td>
                                <td><b>HSN SAC</b></td>
                                <td colspan="4" style="border-left: 1px solid "></td>
                            </tr>
                            <tr style="border-bottom: 2px double">
                                <td style="width: 5%"><b>SRNO</b></td>
                                <td colspan="4" style="width: 40%"><b>DESCRIPTION</b></td>
                                <td style="width: 10%;"><b>QUANTITY</b></td>
                                <td style="width: 10%;"><b>RATE</b></td>
                                <td style="width: 10%;"><b>AMOUNT</b></td>
                            </tr>
                            <?php $a = 1 ?>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr style="    border: 1px solid;">
                                    <td><b><?php echo e($a); ?></b></td>
                                    <td colspan="4">
                                        <?php echo e($item->description); ?>

                                        <span style="display: block;"><b>Note</b> : <?php echo e($item->note); ?></span>
                                    </td>
                                    <td><?php echo e($item->quantity); ?></td>
                                    <td><?php echo e($item->rate); ?></td>
                                    <td><?php echo e($item->amount); ?></td>
                                </tr>
                                <?php $a++ ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td colspan="5"></td>
                                <td colspan="2" style="border-left: 1px solid;"><b>AMOUNT</b></td>
                                <td style="font-size: 14px;"><?php echo e($invoice->amount); ?></td>
                            </tr>
                            <tr>
                                <td colspan="5"></td>
                                <td colspan="2" style="border-left: 1px solid;"><b>TAX (<?php echo e($invoice->tax); ?>)</b></td>
                                <td style="font-size: 14px; "><?php echo e($invoice->taxamount); ?></td>
                            </tr>
                            <tr style=" border-bottom: 1px solid">
                                <td colspan="5" style="font-size: 14px"> <b>Inwords :</b> <?php echo e(number_to_words($invoice->totalamount)); ?> Only.</td>
                                <td colspan="2" style=" border-bottom: 1px solid;border-left: 1px solid;"><b>TOTAL AMOUNT:</b></td>
                                <td style="font-size: 14px;  border-bottom: 1px solid"><?php echo e($invoice->totalamount); ?></td>
                            </tr>
                            <tr>
                              <td colspan="2">
                                  <?php echo e($qr); ?>

                              </td>
                              <td colspan="4"></td>
                              <td colspan="2">
                                <img src="data:image/png;base64,<?php echo e(base64_encode($company->stamp)); ?>" alt="stamp"
                                        style="max-width: 100px; max-height: 100px;">
                              </td>
                            </tr>
                            <tr style="border-bottom: 1px solid;">
                                <td colspan="8" style="text-align: center">TERMS & CONDITION :
                                    <?php echo e($company->terms_and_conditions); ?></td>
                            </tr>

                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>


        </div>

    </main>


    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>

    <!-- Bootstrap Bundle (includes Popper) -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>

    <!-- DataTables -->
    <script src="https://cdn.datatables.net/2.0.1/js/dataTables.js"></script>
    <script src="https://cdn.datatables.net/2.0.1/js/dataTables.bootstrap5.js"></script>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">

    <!-- DataTables Bootstrap 5 CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/2.0.1/css/dataTables.bootstrap5.css">

    <style>
        td{
            padding: 5px
        }
        @media print {
    .navbar,
    .sidebar,
    .gif {
        display: none !important;
    }

    td {
        padding: 4px !important;
    }

    .outer, table {
        width: 98% !important;
        margin: auto !important;
    }

    .break-page {
        page-break-after: always;
    }

    @page {
        size: a4 portrait; /* Set the page size to auto */
        orphans: 0; /* Prevent orphans */
        widows: 0; /* Prevent widows */
    }
}


.middle , .print{
    width: 74%;
    text-align: center;
    display: flex;
    justify-content: center;
    align-items: center;
    height: auto; /* Ensures full height */
}

.middle h4 {
    margin: 0;
}



        @page{
            width: 100%;

            @top-right {
                content: "Page " counter(pageNumber);
            }

            table {
                display: none;
            }

            .container-fluid {
                page-break-after: always;
                break-after: page;
                }
        }

        @page wide {
        size: a4 portrait;
        }
    </style>

    <script>
        new DataTable('#example');
        
        function printinvoice(){
            window.print();
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel_invoice\resources\views/Invoice/show.blade.php ENDPATH**/ ?>