<?php

function getduplicates($array){
    
   for($i =0; $i<count($array); $i++){

        for($j = 0; $j <count($array); $j++){
            if($i != $j){

                $count = 1;

                if ($array[$i] == $array[$j]){

                    echo "[";

                    echo $array[$i]." ".$count;
                    $count++;
                    echo "]";
                }


            }
        }
   }
}



$array = array(12,24,9,2,0,3,6,4,6,4, 6);

echo getduplicates($array);

